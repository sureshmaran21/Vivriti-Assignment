package com.miniproject.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.miniproject.entity.EmployeeDetails;

import java.util.*;
@Repository
public interface EmployeeDetailsRepo extends CrudRepository<EmployeeDetails, Integer>{
   
	EmployeeDetails findByUserId(int userId);
	
	List<EmployeeDetails> findAll();
}
